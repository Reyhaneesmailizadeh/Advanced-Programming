
<form method = "post" action = "createuser.php">
<input type = "text" name = "username">
<input type = "text" name = "pass">
<input type = "submit">
</form>
