<?php
if($_GET['Status'] == 'OK')
{
    echo "Transaction Succeded!";
}
else {
    echo "No Transaction has been done!";
}
?>