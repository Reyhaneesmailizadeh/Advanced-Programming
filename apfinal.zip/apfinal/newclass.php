<?php
include 'commodity.php';

$commodities = new ManageCommodities;

?>